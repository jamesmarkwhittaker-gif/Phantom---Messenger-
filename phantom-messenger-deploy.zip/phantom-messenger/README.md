# 👻 Phantom — Military-Grade Encrypted Messenger

> No phone number. No metadata. No traces. Just privacy.

---

## 🚀 Deploy in 5 Steps (Free)

### Step 1 — Create GitHub Account
1. Go to [github.com](https://github.com)
2. Click **Sign Up** and create your free account
3. Verify your email

---

### Step 2 — Create New Repository
1. Click the **+** button (top right)
2. Click **New Repository**
3. Name it: `phantom-messenger`
4. Set to **Public**
5. Click **Create Repository**

---

### Step 3 — Upload These Files
1. Click **Upload Files** in your new repository
2. Drag and drop ALL files from this folder
3. Keep the folder structure exactly as-is:
```
phantom-messenger/
├── package.json
├── vercel.json
├── .gitignore
├── public/
│   ├── index.html
│   └── manifest.json
└── src/
    ├── index.js
    └── App.jsx
```
4. Click **Commit Changes**

---

### Step 4 — Create Vercel Account
1. Go to [vercel.com](https://vercel.com)
2. Click **Sign Up**
3. Choose **Continue with GitHub**
4. This links your accounts automatically

---

### Step 5 — Deploy
1. Click **Add New Project**
2. Select **phantom-messenger** repository
3. Leave all settings as default
4. Click **Deploy**
5. Wait ~2 minutes
6. Vercel gives you a live URL like: `phantom-messenger.vercel.app`

---

## 📱 How Testers Install It

### iPhone
1. Open your Vercel URL in **Safari**
2. Tap the **Share** button (box with arrow)
3. Tap **Add to Home Screen**
4. Tap **Add**
5. Phantom appears on home screen like a real app

### Android
1. Open your Vercel URL in **Chrome**
2. Tap **Menu** (three dots, top right)
3. Tap **Install App** or **Add to Home Screen**
4. Tap **Install**
5. Phantom appears on home screen

---

## 💬 How to Start Chatting

1. **Person A** opens app → taps **Generate Anonymous Identity**
2. **Person A** copies their **Session ID**
3. **Person A** sends Session ID to **Person B** (via text, email, etc)
4. **Person B** opens app → taps **Generate Anonymous Identity**
5. **Person B** pastes **Person A's Session ID** → taps **Connect**
6. Encrypted channel established — start messaging

---

## 🔐 Security Features

| Feature | Status |
|---|---|
| AES-256-GCM Encryption | ✅ Active |
| Zero Phone Number Required | ✅ Active |
| Anonymous Identity | ✅ Active |
| Disappearing Messages | ✅ Active |
| Emergency Wipe | ✅ Active |
| Security Fingerprint | ✅ Active |
| Zero Server Storage | ✅ Active |
| Typing Indicators | ✅ Active |

---

## 💰 Cost Breakdown

| Service | Cost |
|---|---|
| GitHub | FREE |
| Vercel Hosting | FREE |
| Domain (optional) | ~$12/year |
| **Total** | **$0** |

---

## 🌐 Optional — Add Custom Domain

1. Buy domain at [namecheap.com](https://namecheap.com) (~$12/year)
2. In Vercel dashboard → your project → **Settings → Domains**
3. Add your domain
4. Follow Vercel's DNS instructions (5 min setup)
5. Your app is now live at your own domain

---

*Phantom — Privacy is not a privilege. It's a right.*
