import { useState, useEffect, useRef } from "react";

// ─── Crypto Utilities ───────────────────────────────────────────────────────

async function generateKeyPair() {
  const keyPair = await window.crypto.subtle.generateKey(
    { name: "ECDH", namedCurve: "P-256" },
    true,
    ["deriveKey"]
  );
  const publicKeyRaw = await window.crypto.subtle.exportKey("spki", keyPair.publicKey);
  const privateKeyRaw = await window.crypto.subtle.exportKey("pkcs8", keyPair.privateKey);
  return {
    publicKey: keyPair.publicKey,
    privateKey: keyPair.privateKey,
    publicKeyB64: btoa(String.fromCharCode(...new Uint8Array(publicKeyRaw))),
    privateKeyB64: btoa(String.fromCharCode(...new Uint8Array(privateKeyRaw))),
    fingerprint: await generateFingerprint(publicKeyRaw),
  };
}

async function generateFingerprint(keyBuffer) {
  const hash = await window.crypto.subtle.digest("SHA-256", keyBuffer);
  return Array.from(new Uint8Array(hash))
    .slice(0, 8)
    .map(b => b.toString(16).padStart(2, "0"))
    .join(":")
    .toUpperCase();
}

async function deriveSharedKey(privateKey, publicKeyB64) {
  const raw = Uint8Array.from(atob(publicKeyB64), c => c.charCodeAt(0));
  const importedPub = await window.crypto.subtle.importKey(
    "spki", raw, { name: "ECDH", namedCurve: "P-256" }, false, []
  );
  return window.crypto.subtle.deriveKey(
    { name: "ECDH", public: importedPub },
    privateKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

async function encryptMessage(sharedKey, plaintext) {
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const encoded = new TextEncoder().encode(plaintext);
  const ciphertext = await window.crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    sharedKey,
    encoded
  );
  return {
    iv: btoa(String.fromCharCode(...iv)),
    ciphertext: btoa(String.fromCharCode(...new Uint8Array(ciphertext))),
  };
}

async function decryptMessage(sharedKey, iv, ciphertext) {
  const ivArr = Uint8Array.from(atob(iv), c => c.charCodeAt(0));
  const ctArr = Uint8Array.from(atob(ciphertext), c => c.charCodeAt(0));
  const decrypted = await window.crypto.subtle.decrypt(
    { name: "AES-GCM", iv: ivArr },
    sharedKey,
    ctArr
  );
  return new TextDecoder().decode(decrypted);
}

function generateUsername() {
  const adjectives = ["Silent", "Ghost", "Cipher", "Shadow", "Stealth", "Phantom", "Covert", "Secure"];
  const nouns = ["Fox", "Hawk", "Wolf", "Eagle", "Raven", "Lynx", "Viper", "Falcon"];
  const num = Math.floor(Math.random() * 9000) + 1000;
  return `${adjectives[Math.floor(Math.random() * adjectives.length)]}${nouns[Math.floor(Math.random() * nouns.length)]}${num}`;
}

// ─── Shared Message Bus (simulates relay server in-memory) ──────────────────
const MESSAGE_BUS = { listeners: {}, messages: [] };
function busSubscribe(sessionId, cb) { MESSAGE_BUS.listeners[sessionId] = cb; }
function busUnsubscribe(sessionId) { delete MESSAGE_BUS.listeners[sessionId]; }
function busPublish(payload) {
  MESSAGE_BUS.messages.push(payload);
  Object.values(MESSAGE_BUS.listeners).forEach(cb => cb(payload));
}

// ─── Components ─────────────────────────────────────────────────────────────

const COLORS = {
  bg: "#0a0a0f",
  surface: "#111118",
  panel: "#16161f",
  border: "#1e1e2e",
  accent: "#7c3aed",
  accentGlow: "#7c3aed33",
  accentLight: "#a78bfa",
  green: "#10b981",
  greenGlow: "#10b98120",
  red: "#ef4444",
  text: "#f1f0ff",
  textMuted: "#6b6b8a",
  textDim: "#3d3d5c",
  bubble1: "#1e1040",
  bubble2: "#1a1a2e",
};

function PhantomApp() {
  const [phase, setPhase] = useState("boot"); // boot | setup | pairing | chat
  const [identity, setIdentity] = useState(null);
  const [peerPublicKey, setPeerPublicKey] = useState("");
  const [sharedKey, setSharedKey] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sessionId] = useState(() => Math.random().toString(36).slice(2));
  const [pairedWith, setPairedWith] = useState(null);
  const [timerDefault, setTimerDefault] = useState(30);
  const [showFingerprint, setShowFingerprint] = useState(false);
  const [encryptionLog, setEncryptionLog] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [copied, setCopied] = useState(false);
  const [duressInput, setDuressInput] = useState("");
  const [showDuress, setShowDuress] = useState(false);
  const messagesEndRef = useRef(null);
  const typingTimer = useRef(null);

  useEffect(() => {
    setTimeout(() => setPhase("setup"), 1800);
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    busSubscribe(sessionId, async (payload) => {
      if (payload.to !== sessionId) return;
      if (payload.type === "pair_request") {
        setPeerPublicKey(payload.publicKey);
        setPairedWith(payload.username);
        if (identity) {
          const sk = await deriveSharedKey(identity.privateKey, payload.publicKey);
          setSharedKey(sk);
          busPublish({ type: "pair_accept", to: payload.from, from: sessionId, publicKey: identity.publicKeyB64, username: identity.username });
        }
      }
      if (payload.type === "pair_accept") {
        const sk = await deriveSharedKey(identity.privateKey, payload.publicKey);
        setSharedKey(sk);
        setPairedWith(payload.username);
        setPhase("chat");
      }
      if (payload.type === "message" && sharedKey) {
        try {
          const text = await decryptMessage(sharedKey, payload.iv, payload.ciphertext);
          const msg = { id: payload.msgId, from: "them", text, timestamp: Date.now(), expiresIn: payload.timer };
          setMessages(prev => [...prev, msg]);
          setEncryptionLog(prev => [...prev.slice(-4), { id: payload.msgId, status: "✓ Decrypted AES-256-GCM", key: payload.ciphertext.slice(0, 16) + "..." }]);
          if (payload.timer > 0) {
            setTimeout(() => setMessages(prev => prev.filter(m => m.id !== payload.msgId)), payload.timer * 1000);
          }
        } catch (e) {}
      }
      if (payload.type === "typing") setIsTyping(true);
      if (payload.type === "stop_typing") setIsTyping(false);
    });
    return () => busUnsubscribe(sessionId);
  }, [sessionId, sharedKey, identity]);

  async function createIdentity() {
    const kp = await generateKeyPair();
    const username = generateUsername();
    const id = { ...kp, username, sessionId };
    setIdentity(id);
    setPhase("pairing");
  }

  async function sendPairRequest(targetId) {
    if (!targetId.trim() || !identity) return;
    busPublish({ type: "pair_request", to: targetId.trim(), from: sessionId, publicKey: identity.publicKeyB64, username: identity.username });
    setPhase("chat");
  }

  async function sendMessage() {
    if (!input.trim() || !sharedKey) return;
    const msgId = Math.random().toString(36).slice(2);
    const { iv, ciphertext } = await encryptMessage(sharedKey, input);
    const msg = { id: msgId, from: "me", text: input, timestamp: Date.now(), expiresIn: timerDefault };
    setMessages(prev => [...prev, msg]);
    setEncryptionLog(prev => [...prev.slice(-4), { id: msgId, status: "✓ Sent AES-256-GCM", key: ciphertext.slice(0, 16) + "..." }]);
    busPublish({ type: "message", to: peerPublicKey ? sessionId : "broadcast", iv, ciphertext, msgId, timer: timerDefault, from: sessionId });
    // send to all paired sessions
    Object.keys(MESSAGE_BUS.listeners).forEach(lid => {
      if (lid !== sessionId) busPublish({ type: "message", to: lid, iv, ciphertext, msgId, timer: timerDefault, from: sessionId });
    });
    if (timerDefault > 0) setTimeout(() => setMessages(prev => prev.filter(m => m.id !== msgId)), timerDefault * 1000);
    setInput("");
    busPublish({ type: "stop_typing", to: "all" });
  }

  function handleTyping(val) {
    setInput(val);
    Object.keys(MESSAGE_BUS.listeners).forEach(lid => { if (lid !== sessionId) busPublish({ type: "typing", to: lid }); });
    clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => {
      Object.keys(MESSAGE_BUS.listeners).forEach(lid => { if (lid !== sessionId) busPublish({ type: "stop_typing", to: lid }); });
    }, 1500);
  }

  function copySessionId() {
    navigator.clipboard.writeText(sessionId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function duressWipe() {
    setMessages([]);
    setIdentity(null);
    setSharedKey(null);
    setPairedWith(null);
    setPhase("setup");
    setShowDuress(false);
  }

  const formatTime = (ts) => new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

  // ── BOOT SCREEN ──
  if (phase === "boot") return (
    <div style={{ background: COLORS.bg, height: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontFamily: "'Inter', sans-serif" }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 64, marginBottom: 16 }}>👻</div>
        <div style={{ fontSize: 32, fontWeight: 800, color: COLORS.text, letterSpacing: "-1px" }}>PHANTOM</div>
        <div style={{ fontSize: 13, color: COLORS.textMuted, letterSpacing: "4px", marginTop: 4 }}>SECURE MESSENGER</div>
        <div style={{ marginTop: 32, display: "flex", gap: 6, justifyContent: "center" }}>
          {[0,1,2].map(i => (
            <div key={i} style={{ width: 8, height: 8, borderRadius: "50%", background: COLORS.accent, animation: `pulse 1.2s ease-in-out ${i * 0.4}s infinite` }} />
          ))}
        </div>
        <div style={{ marginTop: 16, fontSize: 12, color: COLORS.textDim }}>Initializing secure environment...</div>
      </div>
      <style>{`@keyframes pulse { 0%,100%{opacity:.2;transform:scale(.8)} 50%{opacity:1;transform:scale(1)} }`}</style>
    </div>
  );

  // ── SETUP SCREEN ──
  if (phase === "setup") return (
    <div style={{ background: COLORS.bg, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Inter', sans-serif", padding: 24 }}>
      <div style={{ maxWidth: 420, width: "100%", textAlign: "center" }}>
        <div style={{ fontSize: 52, marginBottom: 8 }}>👻</div>
        <div style={{ fontSize: 28, fontWeight: 800, color: COLORS.text, letterSpacing: "-0.5px" }}>PHANTOM</div>
        <div style={{ fontSize: 11, color: COLORS.textMuted, letterSpacing: "4px", marginBottom: 32 }}>MILITARY-GRADE ENCRYPTED MESSENGER</div>

        <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.border}`, borderRadius: 20, padding: 28, marginBottom: 20 }}>
          <div style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 20, lineHeight: 1.6 }}>
            No phone number. No email. No identity.<br/>Your keys are generated on your device only.
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {[["🔐", "AES-256-GCM Encryption"], ["🌐", "Zero Metadata Logging"], ["👤", "Anonymous Identity"], ["💨", "Disappearing Messages"]].map(([icon, label]) => (
              <div key={label} style={{ display: "flex", alignItems: "center", gap: 10, background: COLORS.surface, borderRadius: 10, padding: "10px 14px" }}>
                <span style={{ fontSize: 16 }}>{icon}</span>
                <span style={{ fontSize: 13, color: COLORS.accentLight }}>{label}</span>
              </div>
            ))}
          </div>
        </div>

        <button onClick={createIdentity} style={{ width: "100%", padding: "16px", background: `linear-gradient(135deg, ${COLORS.accent}, #5b21b6)`, border: "none", borderRadius: 14, color: "#fff", fontSize: 16, fontWeight: 700, cursor: "pointer", letterSpacing: "0.5px", boxShadow: `0 0 30px ${COLORS.accentGlow}` }}>
          Generate Anonymous Identity
        </button>
        <div style={{ fontSize: 11, color: COLORS.textDim, marginTop: 12 }}>Keys generated locally. Nothing sent to any server.</div>
      </div>
    </div>
  );

  // ── PAIRING SCREEN ──
  if (phase === "pairing") return (
    <div style={{ background: COLORS.bg, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Inter', sans-serif", padding: 24 }}>
      <div style={{ maxWidth: 440, width: "100%" }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{ fontSize: 40, marginBottom: 8 }}>👻</div>
          <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.text }}>Identity Created</div>
          <div style={{ fontSize: 13, color: COLORS.green, marginTop: 4 }}>✓ Keys generated on-device</div>
        </div>

        {/* Identity Card */}
        <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.accent}44`, borderRadius: 20, padding: 20, marginBottom: 16 }}>
          <div style={{ fontSize: 11, color: COLORS.textMuted, letterSpacing: "2px", marginBottom: 12 }}>YOUR IDENTITY</div>
          <div style={{ fontSize: 20, fontWeight: 700, color: COLORS.text, marginBottom: 8 }}>@{identity?.username}</div>
          <div style={{ fontSize: 11, color: COLORS.textMuted, marginBottom: 4 }}>Session ID (share with peer to connect)</div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <div style={{ flex: 1, background: COLORS.surface, borderRadius: 8, padding: "8px 12px", fontSize: 11, color: COLORS.accentLight, fontFamily: "monospace", wordBreak: "break-all" }}>
              {sessionId}
            </div>
            <button onClick={copySessionId} style={{ padding: "8px 14px", background: copied ? COLORS.green : COLORS.accent, border: "none", borderRadius: 8, color: "#fff", fontSize: 12, cursor: "pointer", whiteSpace: "nowrap", transition: "background 0.2s" }}>
              {copied ? "✓ Copied" : "Copy"}
            </button>
          </div>

          <button onClick={() => setShowFingerprint(!showFingerprint)} style={{ marginTop: 10, background: "none", border: `1px solid ${COLORS.border}`, borderRadius: 8, color: COLORS.textMuted, fontSize: 12, padding: "6px 12px", cursor: "pointer" }}>
            {showFingerprint ? "Hide" : "Show"} Security Fingerprint
          </button>
          {showFingerprint && (
            <div style={{ marginTop: 10, background: COLORS.surface, borderRadius: 8, padding: 12 }}>
              <div style={{ fontSize: 11, color: COLORS.textMuted, marginBottom: 4 }}>VERIFY WITH PEER IN PERSON</div>
              <div style={{ fontFamily: "monospace", fontSize: 13, color: COLORS.green, letterSpacing: "2px" }}>{identity?.fingerprint}</div>
            </div>
          )}
        </div>

        {/* Connect to Peer */}
        <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.border}`, borderRadius: 20, padding: 20 }}>
          <div style={{ fontSize: 11, color: COLORS.textMuted, letterSpacing: "2px", marginBottom: 12 }}>CONNECT TO PEER</div>
          <div style={{ fontSize: 12, color: COLORS.textMuted, marginBottom: 12 }}>
            Open this app in another tab/device. Copy their Session ID and paste below.
          </div>
          <input
            placeholder="Paste peer's Session ID here..."
            onChange={e => setPeerPublicKey(e.target.value)}
            style={{ width: "100%", padding: "12px 14px", background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 10, color: COLORS.text, fontSize: 13, outline: "none", boxSizing: "border-box", marginBottom: 10 }}
          />
          <button onClick={() => sendPairRequest(peerPublicKey)} style={{ width: "100%", padding: 14, background: `linear-gradient(135deg, ${COLORS.accent}, #5b21b6)`, border: "none", borderRadius: 12, color: "#fff", fontSize: 14, fontWeight: 700, cursor: "pointer" }}>
            Establish Encrypted Connection
          </button>
          <div style={{ marginTop: 10, textAlign: "center", fontSize: 11, color: COLORS.textDim }}>
            Or wait — if they paste your ID first, you'll connect automatically
          </div>
        </div>
      </div>
    </div>
  );

  // ── CHAT SCREEN ──
  return (
    <div style={{ background: COLORS.bg, height: "100vh", display: "flex", flexDirection: "column", fontFamily: "'Inter', sans-serif", maxWidth: 480, margin: "0 auto" }}>

      {/* Header */}
      <div style={{ background: COLORS.panel, borderBottom: `1px solid ${COLORS.border}`, padding: "14px 18px", display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ fontSize: 26 }}>👻</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: COLORS.text }}>
            {pairedWith ? `@${pairedWith}` : "Waiting for peer..."}
          </div>
          <div style={{ fontSize: 11, color: pairedWith ? COLORS.green : COLORS.textMuted, display: "flex", alignItems: "center", gap: 4 }}>
            {pairedWith ? <><span style={{ width: 6, height: 6, borderRadius: "50%", background: COLORS.green, display: "inline-block" }} /> E2E Encrypted · AES-256-GCM</> : "🔒 Securing channel..."}
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => setShowFingerprint(!showFingerprint)} title="Verify Identity" style={{ background: COLORS.surface, border: `1px solid ${COLORS.border}`, borderRadius: 8, color: COLORS.textMuted, fontSize: 14, padding: "6px 10px", cursor: "pointer" }}>🔑</button>
          <button onClick={() => setShowDuress(!showDuress)} title="Emergency Wipe" style={{ background: COLORS.surface, border: `1px solid ${COLORS.red}44`, borderRadius: 8, color: COLORS.red, fontSize: 14, padding: "6px 10px", cursor: "pointer" }}>🚨</button>
        </div>
      </div>

      {/* Fingerprint Panel */}
      {showFingerprint && (
        <div style={{ background: "#0d1f0d", borderBottom: `1px solid ${COLORS.green}33`, padding: "12px 18px" }}>
          <div style={{ fontSize: 11, color: COLORS.green, letterSpacing: "2px", marginBottom: 4 }}>SECURITY FINGERPRINT — VERIFY IN PERSON</div>
          <div style={{ fontFamily: "monospace", fontSize: 13, color: COLORS.green }}>{identity?.fingerprint}</div>
          <div style={{ fontSize: 11, color: "#4a7c59", marginTop: 4 }}>Your: @{identity?.username} · Session: {sessionId.slice(0, 12)}...</div>
        </div>
      )}

      {/* Duress Panel */}
      {showDuress && (
        <div style={{ background: "#1a0505", borderBottom: `1px solid ${COLORS.red}44`, padding: "12px 18px" }}>
          <div style={{ fontSize: 12, color: COLORS.red, marginBottom: 8, fontWeight: 700 }}>⚠️ EMERGENCY WIPE — This will delete all messages and reset identity</div>
          <div style={{ display: "flex", gap: 8 }}>
            <input placeholder="Type WIPE to confirm" onChange={e => setDuressInput(e.target.value)} style={{ flex: 1, padding: "8px 12px", background: COLORS.surface, border: `1px solid ${COLORS.red}44`, borderRadius: 8, color: COLORS.text, fontSize: 12, outline: "none" }} />
            <button onClick={() => duressInput === "WIPE" && duressWipe()} style={{ padding: "8px 14px", background: duressInput === "WIPE" ? COLORS.red : "#3d1515", border: "none", borderRadius: 8, color: "#fff", fontSize: 12, cursor: "pointer" }}>Wipe</button>
          </div>
        </div>
      )}

      {/* Session ID reminder */}
      {!pairedWith && (
        <div style={{ background: `${COLORS.accent}11`, borderBottom: `1px solid ${COLORS.accent}33`, padding: "10px 18px", display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ flex: 1, fontSize: 11, color: COLORS.accentLight }}>Your Session ID: <span style={{ fontFamily: "monospace" }}>{sessionId}</span></div>
          <button onClick={copySessionId} style={{ padding: "4px 10px", background: COLORS.accent, border: "none", borderRadius: 6, color: "#fff", fontSize: 11, cursor: "pointer" }}>{copied ? "✓" : "Copy"}</button>
        </div>
      )}

      {/* Messages */}
      <div style={{ flex: 1, overflowY: "auto", padding: "16px 14px", display: "flex", flexDirection: "column", gap: 8 }}>
        {messages.length === 0 && (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: COLORS.textDim, textAlign: "center", gap: 12 }}>
            <div style={{ fontSize: 48 }}>🔐</div>
            <div style={{ fontSize: 14, color: COLORS.textMuted }}>Messages are end-to-end encrypted</div>
            <div style={{ fontSize: 12 }}>Nobody else can read this conversation</div>
            {pairedWith && <div style={{ fontSize: 12, color: COLORS.green }}>✓ Secure channel established with @{pairedWith}</div>}
          </div>
        )}

        {messages.map(msg => (
          <div key={msg.id} style={{ display: "flex", flexDirection: "column", alignItems: msg.from === "me" ? "flex-end" : "flex-start" }}>
            <div style={{
              maxWidth: "78%",
              background: msg.from === "me" ? `linear-gradient(135deg, ${COLORS.accent}, #5b21b6)` : COLORS.panel,
              border: msg.from === "me" ? "none" : `1px solid ${COLORS.border}`,
              borderRadius: msg.from === "me" ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
              padding: "10px 14px",
              boxShadow: msg.from === "me" ? `0 0 20px ${COLORS.accentGlow}` : "none"
            }}>
              <div style={{ fontSize: 14, color: COLORS.text, lineHeight: 1.5 }}>{msg.text}</div>
              <div style={{ fontSize: 10, color: msg.from === "me" ? "#a78bfa88" : COLORS.textDim, marginTop: 4, display: "flex", gap: 8 }}>
                <span>{formatTime(msg.timestamp)}</span>
                {msg.expiresIn > 0 && <span>💨 {msg.expiresIn}s</span>}
                {msg.from === "me" && <span>🔒</span>}
              </div>
            </div>
          </div>
        ))}

        {isTyping && (
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ background: COLORS.panel, border: `1px solid ${COLORS.border}`, borderRadius: "18px 18px 18px 4px", padding: "10px 14px", display: "flex", gap: 4 }}>
              {[0,1,2].map(i => <div key={i} style={{ width: 6, height: 6, borderRadius: "50%", background: COLORS.textMuted, animation: `pulse 1s ${i*0.2}s infinite` }} />)}
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Encryption Log */}
      {encryptionLog.length > 0 && (
        <div style={{ background: "#0a0f0a", borderTop: `1px solid ${COLORS.green}22`, padding: "6px 14px", maxHeight: 60, overflowY: "auto" }}>
          {encryptionLog.slice(-2).map((log, i) => (
            <div key={i} style={{ fontSize: 10, color: "#2d6a4f", fontFamily: "monospace" }}>
              {log.status} · cipher: {log.key}
            </div>
          ))}
        </div>
      )}

      {/* Timer Selector */}
      <div style={{ background: COLORS.panel, borderTop: `1px solid ${COLORS.border}`, padding: "8px 14px", display: "flex", gap: 6, alignItems: "center" }}>
        <span style={{ fontSize: 11, color: COLORS.textMuted }}>💨 Auto-delete:</span>
        {[[0, "Off"], [10, "10s"], [30, "30s"], [300, "5m"], [3600, "1h"]].map(([val, label]) => (
          <button key={val} onClick={() => setTimerDefault(val)} style={{
            padding: "4px 10px", borderRadius: 6, fontSize: 11, cursor: "pointer", border: "none",
            background: timerDefault === val ? COLORS.accent : COLORS.surface,
            color: timerDefault === val ? "#fff" : COLORS.textMuted,
            transition: "all 0.15s"
          }}>{label}</button>
        ))}
      </div>

      {/* Input */}
      <div style={{ background: COLORS.panel, borderTop: `1px solid ${COLORS.border}`, padding: "12px 14px", display: "flex", gap: 10, alignItems: "flex-end" }}>
        <input
          value={input}
          onChange={e => handleTyping(e.target.value)}
          onKeyDown={e => e.key === "Enter" && !e.shiftKey && sendMessage()}
          placeholder={pairedWith ? "Type a message... (AES-256 encrypted)" : "Waiting for peer to connect..."}
          disabled={!pairedWith}
          style={{
            flex: 1, padding: "12px 16px", background: COLORS.surface,
            border: `1px solid ${COLORS.border}`, borderRadius: 24,
            color: COLORS.text, fontSize: 14, outline: "none",
            opacity: pairedWith ? 1 : 0.5
          }}
        />
        <button onClick={sendMessage} disabled={!pairedWith || !input.trim()} style={{
          width: 46, height: 46, borderRadius: "50%", border: "none", cursor: "pointer",
          background: pairedWith && input.trim() ? `linear-gradient(135deg, ${COLORS.accent}, #5b21b6)` : COLORS.surface,
          color: "#fff", fontSize: 18, display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: pairedWith && input.trim() ? `0 0 20px ${COLORS.accentGlow}` : "none",
          transition: "all 0.2s", flexShrink: 0
        }}>➤</button>
      </div>

      <style>{`
        * { box-sizing: border-box; }
        input::placeholder { color: #3d3d5c; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #1e1e2e; border-radius: 2px; }
        @keyframes pulse { 0%,100%{opacity:.3;transform:scale(.8)} 50%{opacity:1;transform:scale(1)} }
      `}</style>
    </div>
  );
}

export default PhantomApp;
